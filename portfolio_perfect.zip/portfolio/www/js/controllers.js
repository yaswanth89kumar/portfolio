angular.module('starter.controllers', [])

.controller('DashCtrl', function ($scope, Chats) {
    $scope.books = Chats.allbooks();

    $scope.chunk = function chunk(arr, size) {
        var newArr = [];
        for (var i = 0; i < arr.length; i += size) {
            newArr.push(arr.slice(i, i + size));
        }
        return newArr;
    }

    $scope.chunkedData = $scope.chunk($scope.books, 4);
})

.controller('searchCtrl', function ($scope, Chats) {})

.controller('ChatsCtrl', function ($scope, Chats) {
    // With the new view caching in Ionic, Controllers are only called
    // when they are recreated or on app start, instead of every page change.
    // To listen for when this page is active (for example, to refresh data),
    // listen for the $ionicView.enter event:
    //
    //$scope.$on('$ionicView.enter', function(e) {
    //});

    $scope.chats = Chats.location();
    $scope.stores = Chats.allstores();
    $scope.remove = function (chat) {
        Chats.remove(chat);
    };
})

.controller('ChatDetailCtrl', function ($scope, $stateParams, Chats) {
    $scope.chat = Chats.getstorelocations($stateParams.chatId);
})

.controller('bookDetailCtrl', function ($scope, $stateParams, Chats) {
    $scope.chat = Chats.getbook($stateParams.chatId);
    $scope.stores = [];
    for (i = 0; i < $scope.chat.store.length; i++) {
        $scope.stores.push(Chats.getstore($scope.chat.store[i]));
    }

})

.controller('quoteDetailCtrl', function ($scope, $stateParams, Chats) {
    $scope.store = Chats.getstore($stateParams.chatId);

})

.controller('AccountCtrl', function ($scope) {
    $scope.settings = {
        enableFriends: true
    };
});
