angular.module('starter.services', [])

.factory('Chats', function () {
    // Might use a resource here that returns a JSON array

    var locations = [{
        id: '1'
        , name: 'bangalore'
        , face: 'img/bangalore.png'
        , description: 'Books available at bangalore'
    }, {
        id: '2'
        , name: 'chennai'
        , face: 'img/chennai.png'
        , description: 'Books available at chennai'
    }, {
        id: '3'
        , name: 'vishakapattanam'
        , face: 'img/vizag.png'
        , description: 'Books available at vishakappatanam'
    }];
    var stores = [{
            id: 1
            , details: [{
                location: 1
                , location_name: 'bangalore'
                , name: 'Gayathri Book Store'
                , address: 'Near Majestic'
                , phone: '21234567890'
                }, {
                location: 2
                , location_name: 'chennai'
                , name: 'Gayathri Book Store'
                , address: 'Near Shivaji bus stop'
                , phone: '11234567890'
            }]

            },{
            id: 2
            , details: [{
                location: 1
                , location_name: 'bangalore'
                , name: 'sachin Book Store'
                , address: 'Near Majestic'
                , phone: '21234567891'
                }, {
                location: 2
                , location_name: 'chennai'
                , name: 'sachin Book Store'
                , address: 'Near Shivaji bus stop'
                , phone: '11234567891'
            }]

            }]
        // Some fake testing data
    var chats = [{
            id: 10001
            , name: 'C'
            , description: 'Programming language book'
            , face: 'img/c.png'
            , store: ['1']
            , price: 600
    }, {
            id: 10002
            , name: 'CPP'
            , description: 'Programming language book'
            , face: 'img/cpp.png'
            , store: ['1']
            , price: 600
    }, {
            id: 10003
            , name: 'Java'
            , description: 'Programming language book'
            , face: 'img/java.png'
            , store: ['1']
            , price: 600
    }, {
            id: 10004
            , name: 'Mysql'
            , description: 'Programming language book'
            , face: 'img/mysql.png'
            , store: ['1']
            , price: 600

  }];

    return {
         location: function () {
            return locations;
        },
        all: function () {
            return chats;
        }
        , allstores: function () {
            return stores;
        }
        , allbooks: function () {
            var all_books = [];
            for (var i = 0; i < chats.length; i++) {
                for (var j = 0; j < chats[i].books.length; j++) {
                    all_books.push(chats[i].books[j]);
                }
            }
            return all_books;
        }


        , remove: function (chat) {
            chats.splice(chats.indexOf(chat), 1);
        }
        , get: function (chatId) {
            for (var i = 0; i < chats.length; i++) {
                if (chats[i].id === parseInt(chatId)) {
                    return chats[i];
                }
            }
            return null;
        }
        , getstorelocations: function (chatId) {
            var store_details = [];

            for (var i = 0; i < stores.length; i++) {
                for (var j = 0; j < stores[i].details.length; j++) {
                    if (stores[i].details[j].location === parseInt(chatId)) {
                        store_details.push(stores[i].details[j]);
                    }
                }
            }

            var location = this.getlocation(chatId);
            return [{info : store_details, location : location.name}];
        }
        , getbook: function (chatId) {
            for (var i = 0; i < chats.length; i++) {
                for (var j = 0; j < chats[i].books.length; j++) {
                    if (chats[i].books[j].id === parseInt(chatId)) {
                        return chats[i].books[j];
                    }
                }
            }
            return null;
        }
        , getlocation: function (storeid) {
           for (var i = 0; i < locations.length; i++) {
               if (locations[i].id == parseInt(storeid)) {
                    return locations[i];
                }

            }
            return null;
        }
        , getstore: function (storeid) {
           for (var i = 0; i < stores.length; i++) {
                if (stores[i].id === parseInt(storeid)) {
                    return stores[i];
                }

            }
            return null;
        }
    };
});
