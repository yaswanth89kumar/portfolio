angular.module('starter.services', [])

.factory('Chats', function () {
    // Might use a resource here that returns a JSON array

    var stores = [{
                id: 1
                , name: 'Gayathri Book Store'
                , address: 'Near Majestic'
                , phone: '1234567890'
            }

            , {
                id: 3
                , name: 'Gayathri Book Store'
                , address: 'Near Shivaji bus stop'
                , phone: '1234567890'

            }, {
                id: 2
                , name: 'sachin Book Store'
                , address: 'Near Ramzon bus stop'
                , phone: '1234567890'
            }]
        // Some fake testing data
    var chats = [{
        id: 0
        , name: 'Bangalore'
        , description: 'Books available at bangalore'
        , face: 'img/bangalore.png'
        , books: [{
            id: 10001
            , name: 'C'
            , description: 'Programming language book'
            , face: 'img/c.png'
            , store: ['1']
            , price: 600
    }, {
            id: 10002
            , name: 'CPP'
            , description: 'Programming language book'
            , face: 'img/cpp.png'
            , store: ['1']
            , price: 600
    }, {
            id: 10003
            , name: 'Java'
            , description: 'Programming language book'
            , face: 'img/java.png'
            , store: ['1']
            , price: 600
    }, {
            id: 10004
            , name: 'Mysql'
            , description: 'Programming language book'
            , face: 'img/mysql.png'
            , store: ['1']
            , price: 600
    }]
  }, {
        id: 1
        , name: 'Chennai'
        , description: 'Books available at bangalore'
        , face: 'img/chennai.png'
        , books: [{
            id: 10005
            , name: 'C'
            , description: 'Programming language book'
            , face: 'img/c.png'
            , store: ['3']
            , price: 600
    }, {
            id: 10006
            , name: 'CPP'
            , description: 'Programming language book'
            , face: 'img/cpp.png'
            , store: ['3', '2']
            , price: 600
    }, {
            id: 10007
            , name: 'Java'
            , description: 'Programming language book'
            , face: 'img/java.png'
            , store: ['3']
            , price: 600
    }, {
            id: 10008
            , name: 'Mysql'
            , description: 'Programming language book'
            , face: 'img/mysql.png'
            , store: ['3', '2']
            , price: 600
    }]
  }];

    return {
        all: function () {
            return chats;
        }
        , allstores: function () {
            return stores;
        }
        , remove: function (chat) {
            chats.splice(chats.indexOf(chat), 1);
        }
        , get: function (chatId) {
            for (var i = 0; i < chats.length; i++) {
                if (chats[i].id === parseInt(chatId)) {
                    return chats[i];
                }
            }
            return null;
        }
        , getbook: function (chatId) {
            for (var i = 0; i < chats.length; i++) {
                for (var j = 0; j < chats[i].books.length; j++) {
                    if (chats[i].books[j].id === parseInt(chatId)) {
                         return chats[i].books[j];
                    }
                }
            }
            return null;
        }
        , getstore: function (storeid) {
            for (var i = 0; i < stores.length; i++) {
                if (stores[i].id === parseInt(storeid)) {
                    return stores[i];
                }

            }
            return null;
        }
    };
});
